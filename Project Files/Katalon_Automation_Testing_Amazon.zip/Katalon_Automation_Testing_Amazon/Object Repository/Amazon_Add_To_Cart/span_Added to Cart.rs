<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Added to Cart</name>
   <tag></tag>
   <elementGuidId>bef70e44-99d9-4a7a-a109-a827f86264fd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='NATC_SMART_WAGON_CONF_MSG_SUCCESS']/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.a-size-medium-plus.a-color-base.sw-atc-text.a-text-bold</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>693a1b50-f209-4da9-b5cd-1c4fc3d1866d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-size-medium-plus a-color-base sw-atc-text a-text-bold</value>
      <webElementGuid>53af30bc-04cd-4ce6-9118-fc0a43557a2b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
            Added to Cart
        
    </value>
      <webElementGuid>98066c3e-52cd-4293-bccf-b84a43ee35fe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;NATC_SMART_WAGON_CONF_MSG_SUCCESS&quot;)/span[@class=&quot;a-size-medium-plus a-color-base sw-atc-text a-text-bold&quot;]</value>
      <webElementGuid>0b4a16bd-ad4c-4296-b3d9-dcf4d365e0bc</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='NATC_SMART_WAGON_CONF_MSG_SUCCESS']/span</value>
      <webElementGuid>e1fe0791-6310-4996-88e7-019e2d8a8d77</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/div/div[2]/div/div/div/div/span</value>
      <webElementGuid>e96a262f-04c7-4b09-a765-8c0c67347c59</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
        
            Added to Cart
        
    ' or . = '
        
            Added to Cart
        
    ')]</value>
      <webElementGuid>35c750e5-5e10-4ed6-8bc3-0dfab1c541ba</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

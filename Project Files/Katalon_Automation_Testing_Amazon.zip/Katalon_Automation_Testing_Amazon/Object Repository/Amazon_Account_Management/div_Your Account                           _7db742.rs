<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Your Account                           _7db742</name>
   <tag></tag>
   <elementGuidId>18b6d3f3-f6b2-44de-b7f4-9707915e9e0c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='a-page']/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.a-container</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>14290097-4b40-49f2-8a20-8b37e62322ad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-container</value>
      <webElementGuid>b8e4ab1f-0c72-4e6c-bdd6-28a70825b23a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
      
        






  
    
  







  
    
      
        Your Account
      
    
    
      ›
    
    
      
        
          
          
            Login &amp; Security
          
        
        
          ›
        
        
          Change Your Name
        
      
      
    
  









  

  

  

  
  
  







  
    Change Your Name
  

  
    
      If you want to change the name associated with your Amazon customer account, you may do so below. Be sure to click the Save Changes button when you are done.
    

    
      
    







  
  
  
    

    




  
    
  
    
  
    
  



    
      
      
      
        
      
      
        New name
      
    
    
      
      
      
    

    
    

    
      
      
        
        
      
    

    
    
      
        
          
        








      
    

    
      Save changes
    
  



  


      
    </value>
      <webElementGuid>935ee2d5-cfb5-433e-bff1-725b93d8f232</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[@class=&quot;a-container&quot;]</value>
      <webElementGuid>57d15bf5-4460-45c8-8e66-3dbead93d885</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='a-page']/div</value>
      <webElementGuid>43af0bcb-ca91-40a4-830a-75d19ac478e1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div</value>
      <webElementGuid>2edaf632-2d57-432d-9724-9ad985793697</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
      
        






  
    
  







  
    
      
        Your Account
      
    
    
      ›
    
    
      
        
          
          
            Login &amp; Security
          
        
        
          ›
        
        
          Change Your Name
        
      
      
    
  









  

  

  

  
  
  







  
    Change Your Name
  

  
    
      If you want to change the name associated with your Amazon customer account, you may do so below. Be sure to click the Save Changes button when you are done.
    

    
      
    







  
  
  
    

    




  
    
  
    
  
    
  



    
      
      
      
        
      
      
        New name
      
    
    
      
      
      
    

    
    

    
      
      
        
        
      
    

    
    
      
        
          
        








      
    

    
      Save changes
    
  



  


      
    ' or . = '
      
        






  
    
  







  
    
      
        Your Account
      
    
    
      ›
    
    
      
        
          
          
            Login &amp; Security
          
        
        
          ›
        
        
          Change Your Name
        
      
      
    
  









  

  

  

  
  
  







  
    Change Your Name
  

  
    
      If you want to change the name associated with your Amazon customer account, you may do so below. Be sure to click the Save Changes button when you are done.
    

    
      
    







  
  
  
    

    




  
    
  
    
  
    
  



    
      
      
      
        
      
      
        New name
      
    
    
      
      
      
    

    
    

    
      
      
        
        
      
    

    
    
      
        
          
        








      
    

    
      Save changes
    
  



  


      
    ')]</value>
      <webElementGuid>6c6fe5b8-4090-47fb-97df-a232b8fe2535</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
